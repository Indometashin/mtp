import cv2
import numpy as np
from scipy import optimize
from scipy.optimize import least_squares

def func_fit(par, x):
    a, b, c, offset = par 
    return a * np.sin((x - b) / c) + offset

def func_res(par, x, y):
    return y - func_fit(par, x)


a0 = 50
b0 = 0
c0 = 4
offset0 = 70
par0 = [a0, b0, c0, offset0]

fileimg = 'img50.png'
img50 = cv2.imread(fileimg, cv2.IMREAD_GRAYSCALE)
line50 = img50.mean(axis=0)
np.savetxt('line50.csv', line50)

fileimg = 'img30.png'
img30 = cv2.imread(fileimg, cv2.IMREAD_GRAYSCALE)
line30 = img30.mean(axis=0)
np.savetxt('line30.csv', line30)

fileimg = 'img10.png'
img10 = cv2.imread(fileimg, cv2.IMREAD_GRAYSCALE)
line10 = img10.mean(axis=0)
np.savetxt('line10.csv', line10)


x = np.arange(len(line50))
result = least_squares(func_res, par0, args=(x, line50))
np.savetxt('fit50.csv', func_fit(result.x, x), header=str(result.x))
np.savetxt('init50.csv', func_fit(par0, x), header=str(par0))
contrast0 = (result.x[0] / result.x[3])

a0 = 50
b0 = 0
c0 = 1.8
offset0 = 70
par0 = [a0, b0, c0, offset0]
x = np.arange(len(line30))
result = least_squares(func_res, par0, args=(x, line30))
np.savetxt('fit30.csv', func_fit(result.x, x), header=str(result.x))
np.savetxt('init30.csv', func_fit(par0, x), header=str(par0))
swrf30 = (result.x[0] / result.x[3]) / contrast0

a0 = 20
b0 = 0
c0 = 0.75
offset0 = 75
par0 = [a0, b0, c0, offset0]
x = np.arange(len(line10))
result = least_squares(func_res, par0, args=(x, line10))
np.savetxt('fit10.csv', func_fit(result.x, x), header=str(result.x))
np.savetxt('init10.csv', func_fit(par0, x), header=str(par0))
swrf10 = (result.x[0] / result.x[3]) / contrast0

swrf = f'swrf 30 : {swrf30}, 10 : {swrf10}'
with open('swrf.txt', mode='w') as f:
    f.write(swrf)
print(swrf)