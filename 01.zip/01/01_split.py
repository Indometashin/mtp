import cv2
import numpy as np

fileimg = 'img.jpg'
img = cv2.imread(fileimg, cv2.IMREAD_GRAYSCALE)


x_50 = [110, 270]
y_50 = [270, 350]

x_30 = [105, 205]
y_30 = [10, 85]

x_10 = [250, 350]
y_10 = [10, 85]

img50 = img[y_50[0] : y_50[1], x_50[0] : x_50[1]]
img30 = img[y_30[0] : y_30[1], x_30[0] : x_30[1]]
img10 = img[y_10[0] : y_10[1], x_10[0] : x_10[1]]

cv2.imwrite('img50.png', img50)
cv2.imwrite('img30.png', img30)
cv2.imwrite('img10.png', img10)